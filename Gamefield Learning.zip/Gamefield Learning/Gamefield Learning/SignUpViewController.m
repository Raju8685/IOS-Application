//
//  SignUpViewController.m
//  Gamefield Learning
//
//  Created by Deepu on 04/10/23.
//

#import "SignUpViewController.h"

@interface SignUpViewController ()

@end

@implementation SignUpViewController
- (IBAction)Username:(UITextField *)sender {
}
- (IBAction)Password:(UITextField *)sender {
}
- (IBAction)PhoneNo:(UITextField *)sender {
}
- (IBAction)Mail:(UITextField *)sender {
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}
- (IBAction)SignInClicked:(UITextField *)sender {
    guard let Username = Username.text else { return }
    guard let Password = Password.text else { return }
    guard let Phone No = Phone No.text else { return }
    guard let Mail = Mail.text else { return }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
