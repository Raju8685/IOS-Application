//
//  SignUpViewController.swift
//  Gamefield Learning
//
//  Created by Deepu on 04/10/23.
//

import UIKit
//import Firebase

class SignUpViewController: UIViewController {

    @IBOutlet weak var EmailTextField: UITextField!
    @IBOutlet weak var PasswordTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func SignupClicked(_ sender: UIButton) {
        
        guard let email = EmailTextField.text, !email.isEmpty else {
            // Handle the case where email is empty
            return
        }
        guard let password = PasswordTextField.text, !password.isEmpty else {
            // Handle the case where password is empty
            return
        }
        
        //Auth.auth().createUser(withEmail: email, password: password) { (authResult, error) in
            //if let error = error {
                //print("Error creating user: \(error.localizedDescription)")
           // } else {
                // User signed up successfully, perform the segue to the login page
                
            }
    @IBAction func signin(_ sender: Any) {
        let loginVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
        self.navigationController?.pushViewController(loginVC, animated: true)
    }
}
   // }
//}
