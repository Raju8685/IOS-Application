//
//  LoginViewController.swift
//  Gamefield Learning
//
//  Created by Deepu on 04/10/23.
//

import UIKit
//import Firebase

class LoginViewController: UIViewController {

    @IBOutlet weak var EmailTextField: UITextField!
    @IBOutlet weak var PasswordTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func SignUp(_ sender: Any) {
        let loginVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SignUpViewController") as! SignUpViewController
        self.navigationController?.pushViewController(loginVC, animated: true)
    }
    @IBAction func LoginClicked(_ sender: UIButton) {let loginVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
        self.navigationController?.pushViewController(loginVC, animated: true)
        guard let email = EmailTextField.text, !email.isEmpty else {
            // Handle the case where email is empty
            return
        }
        guard let password = PasswordTextField.text, !password.isEmpty else {
            // Handle the case where password is empty
            return
        }
        
//        Auth.auth().signIn(withEmail: email, password: password) { (authResult, error) in
//            if let error = error {
//                print("Error signing in: \(error.localizedDescription)")
//            } else {
//                // User signed in successfully, you can perform the necessary actions here
//                // For example, you can navigate to another view controller or update the UI
//                print("User signed in successfully!")
//            }
//        }
    }
    
}

